

class User < ApplicationRecord

  


end